// Get the input box element
const inputBox = document.getElementById('inputBox');
let currentInput = '';
let lastCalculation = '';

// Function to update the display
function updateDisplay() {
    inputBox.value = currentInput || '0';
}

// Function to handle button clicks
function calculate(value) {
    if (value === 'Math.pow(') {
        currentInput += '^(';
    } else if (value === 'Math.PI') {
        currentInput += Math.PI.toString();
    } else {
        currentInput += value;
    }
    updateDisplay();
}

// Factorial function
function factorial(n) {
    if (n < 0) return NaN;
    if (n === 0 || n === 1) return 1;
    let result = 1;
    for (let i = 2; i <= n; i++) {
        result *= i;
    }
    return result;
}

// Clear all input
function clearAll() {
    currentInput = '';
    updateDisplay();
}

// Delete last character
function deleteLast() {
    currentInput = currentInput.slice(0, -1);
    updateDisplay();
}

// Calculate percentage
function calculatePercentage() {
    try {
        currentInput = (eval(currentInput) / 100).toString();
        updateDisplay();
    } catch (error) {
        currentInput = 'Error';
        updateDisplay();
        setTimeout(clearAll, 1000);
    }
}

// Main calculation function
function calculateResult() {
    try {
        // Replace ^ with ** for exponentiation
        let expression = currentInput.replace(/\^/g, '**');
        
        // Handle factorial
        expression = expression.replace(/(\d+)!/g, 'factorial($1)');
        
        // Handle percentage if it's at the end
        if (expression.endsWith('%')) {
            expression = expression.slice(0, -1) + '/100';
        }
        
        lastCalculation = currentInput + ' = ' + eval(expression);
        currentInput = eval(expression).toString();
        updateDisplay();
    } catch (error) {
        currentInput = 'Error';
        updateDisplay();
        setTimeout(clearAll, 1000);
    }
}

// Add event listeners to all buttons
document.querySelectorAll('.button').forEach(button => {
    button.addEventListener('click', function() {
        const value = this.textContent;
        
        if (value === 'AC') {
            clearAll();
        } else if (value === 'DEL') {
            deleteLast();
        } else if (value === '%') {
            calculatePercentage();
        } else if (value === '=') {
            calculateResult();
        } else if (this.classList.contains('operator') && value !== '=') {
            calculate(value);
        } else if (!this.classList.contains('operator')) {
            calculate(value);
        }
    });
});

// Keyboard support
document.addEventListener('keydown', function(event) {
    const key = event.key;
    
    if (/[0-9]/.test(key)) {
        calculate(key);
    } else if (key === '+' || key === '-' || key === '*' || key === '/') {
        calculate(key);
    } else if (key === '.') {
        calculate('.');
    } else if (key === 'Enter') {
        calculateResult();
    } else if (key === 'Escape') {
        clearAll();
    } else if (key === 'Backspace') {
        deleteLast();
    } else if (key === '(' || key === ')') {
        calculate(key);
    } else if (key === '^') {
        calculate('Math.pow(');
    } else if (key === '!') {
        calculate('!');
    } else if (key === '%') {
        calculatePercentage();
    } else if (key === 'p' && event.ctrlKey) {
        calculate('Math.PI');
    }
});